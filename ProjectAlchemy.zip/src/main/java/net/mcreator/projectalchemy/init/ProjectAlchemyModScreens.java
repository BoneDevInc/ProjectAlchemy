
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.projectalchemy.init;

import net.mcreator.projectalchemy.client.gui.EMCScreen;

import net.fabricmc.fabric.api.client.screenhandler.v1.ScreenRegistry;

public class ProjectAlchemyModScreens {
	public static void load() {
		ScreenRegistry.register(ProjectAlchemyModMenus.EMC, EMCScreen::new);
	}
}
