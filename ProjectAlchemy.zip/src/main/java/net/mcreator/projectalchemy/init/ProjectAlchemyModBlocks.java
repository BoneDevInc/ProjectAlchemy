
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.projectalchemy.init;

import net.minecraft.world.level.block.Block;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.Registry;

import net.mcreator.projectalchemy.block.AlchemyTableBlock;
import net.mcreator.projectalchemy.ProjectAlchemyMod;

public class ProjectAlchemyModBlocks {
	public static Block ALCHEMY_TABLE;

	public static void load() {
		ALCHEMY_TABLE = Registry.register(Registry.BLOCK, new ResourceLocation(ProjectAlchemyMod.MODID, "alchemy_table"), new AlchemyTableBlock());
	}

	public static void clientLoad() {
		AlchemyTableBlock.clientInit();
	}
}
