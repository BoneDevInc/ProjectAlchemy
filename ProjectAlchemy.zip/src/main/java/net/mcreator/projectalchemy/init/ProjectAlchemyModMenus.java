
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.projectalchemy.init;

import net.minecraft.world.inventory.MenuType;
import net.minecraft.resources.ResourceLocation;

import net.mcreator.projectalchemy.world.inventory.EMCMenu;
import net.mcreator.projectalchemy.client.gui.EMCScreen;
import net.mcreator.projectalchemy.ProjectAlchemyMod;

import net.fabricmc.fabric.api.screenhandler.v1.ScreenHandlerRegistry;

public class ProjectAlchemyModMenus {
	public static MenuType<EMCMenu> EMC;

	public static void load() {
		EMC = ScreenHandlerRegistry.registerExtended(new ResourceLocation(ProjectAlchemyMod.MODID, "emc"), EMCMenu::new);
		EMCScreen.screenInit();
	}
}
