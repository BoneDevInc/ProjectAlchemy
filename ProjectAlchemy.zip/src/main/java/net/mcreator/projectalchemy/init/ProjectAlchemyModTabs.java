
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.projectalchemy.init;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.resources.ResourceLocation;

import net.fabricmc.fabric.api.client.itemgroup.FabricItemGroupBuilder;

public class ProjectAlchemyModTabs {
	public static CreativeModeTab TAB_PROJECT_ALCHEMY;

	public static void load() {
		TAB_PROJECT_ALCHEMY = FabricItemGroupBuilder.create(new ResourceLocation("project_alchemy", "project_alchemy"))
				.icon(() -> new ItemStack(ProjectAlchemyModBlocks.ALCHEMY_TABLE)).build();
	}
}
