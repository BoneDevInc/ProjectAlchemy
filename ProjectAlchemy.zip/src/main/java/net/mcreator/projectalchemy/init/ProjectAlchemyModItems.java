
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.projectalchemy.init;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.Registry;

import net.mcreator.projectalchemy.ProjectAlchemyMod;

public class ProjectAlchemyModItems {
	public static Item ALCHEMY_TABLE;

	public static void load() {
		ALCHEMY_TABLE = Registry.register(Registry.ITEM, new ResourceLocation(ProjectAlchemyMod.MODID, "alchemy_table"),
				new BlockItem(ProjectAlchemyModBlocks.ALCHEMY_TABLE, new Item.Properties().tab(ProjectAlchemyModTabs.TAB_PROJECT_ALCHEMY)));
	}
}
