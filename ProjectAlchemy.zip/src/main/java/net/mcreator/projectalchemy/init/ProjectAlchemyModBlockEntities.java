
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.projectalchemy.init;

import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.Registry;

import net.mcreator.projectalchemy.block.entity.AlchemyTableBlockEntity;
import net.mcreator.projectalchemy.ProjectAlchemyMod;

import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;

public class ProjectAlchemyModBlockEntities {
	public static BlockEntityType<?> ALCHEMY_TABLE;

	public static void load() {
		ALCHEMY_TABLE = Registry.register(Registry.BLOCK_ENTITY_TYPE, new ResourceLocation(ProjectAlchemyMod.MODID, "alchemy_table"),
				FabricBlockEntityTypeBuilder.create(AlchemyTableBlockEntity::new, ProjectAlchemyModBlocks.ALCHEMY_TABLE).build(null));
	}
}
